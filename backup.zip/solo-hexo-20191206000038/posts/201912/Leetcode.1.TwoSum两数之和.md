title: Leetcode.1.Two Sum 两数之和
date: '2019-12-02 14:48:17'
updated: '2019-12-02 15:51:44'
tags: [leetcode]
permalink: /articles/2019/12/02/1575269297549.html
---
![blurcloseupcodecomputer546819.jpg](https://img.hacpai.com/file/2019/12/blurcloseupcodecomputer546819-3631670e.jpg)

### 中文

给定一个整数数组 nums 和一个目标值 target , 请你在该数组中找出和为目标值的那两个整数 , 并返回他们的数组下标 . 

你可以假设每种输入只会对应一个答案 . 但是 , 你不能重复利用这个数组中同样的元素 . 

示例 : 

> 给定 nums = [2, 7, 11, 15], target = 9
>
> 因为 nums[0] + nums[1] = 2 + 7 = 9
> 所以返回 [0, 1]

### 英文

Given an array of integers, return indices of the two numbers such that they add up to a specific target.

You may assume that each input would have exactly one solution, and you may not use the same element twice.

Example:

> Given nums = [2, 7, 11, 15], target = 9,
> 
> Because nums[0] + nums[1] = 2 + 7 = 9,
> return [0, 1].

Java : 

```java
class Solution {
    public int[] twoSum(int[] nums, int target) {
        for (int i = 0; i < nums.length; i++) {
            for (int j = i + 1; j < nums.length; j++) {
                if (nums[j] == target - nums[i]) {
                    return new int[] { i, j };
                }
            }
        }
        throw new IllegalArgumentException("NoReturn");
    }
}
```

PHP : 

```php
class Solution
{
    /**
     * @param Integer[] $nums
     * @param Integer $target
     * @return Integer[]
     */
    function twoSum($nums, $target)
    {
        for ($i = 0; $i < count($nums); $i++) {
            for ($j = $i + 1; $j < count($nums); $j++) {
                if ($nums[$j] === $target - $nums[$i]) {
                    return [$i, $j];
                }
            }
        }
    }
}
```

### 解题思路

#### 暴力法

遍历每个元素x , 并查找是否存在一个值与target−x相等的目标元素 . 

#### 复杂度分析

* 时间复杂度 : O(n^2)
对于每个元素 , 我们试图通过遍历数组的其余部分来寻找它所对应的目标元素 , 这将耗费O(n)的时间 . 因此时间复杂度为O(n^2) . 

* 空间复杂度 : O(1) . 

> **相关连接**
> https://leetcode-cn.com/problems/two-sum/solution/liang-shu-zhi-he-by-leetcode-2/
