title: 'Tip.慌的一匹nginx: [error] invalid PID number "" in "/usr/local/var/run/nginx/nginx.pid"'
date: '2019-12-07 17:03:22'
updated: '2019-12-07 17:03:22'
tags: [tip, nginx]
permalink: /articles/2019/12/07/1575709402445.html
---
![womandroppedfailfailure4091.jpg](https://img.hacpai.com/file/2019/12/womandroppedfailfailure4091-388b465f.jpg)


昨天同事修改了nginx配置文件 , 照例`nginx -t`检查 , 一起正常 . 但是在平滑重启时候居然报错 : 

```
# nginx: [error] invalid PID number "" in "/usr/local/var/run/nginx/nginx.pid"
```

还不知道具体原因是什么 , 已经给大佬留言 , 希望能得到答案 . 

#### 解决方案

```
ps aux | grep nginx 
PID of nginx master process

echo PID > /var/run/nginx.pid
nginx -s reload
```

