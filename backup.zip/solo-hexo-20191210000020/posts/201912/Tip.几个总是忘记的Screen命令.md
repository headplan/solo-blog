title: Tip.几个总是忘记的Screen命令
date: '2019-12-04 10:20:14'
updated: '2019-12-04 10:22:49'
tags: [tip, screen, tmux]
permalink: /articles/2019/12/04/1575426014641.html
---
![informationsignonpaper317356.jpg](https://img.hacpai.com/file/2019/12/informationsignonpaper317356-f28bb1d4.jpg)
* [Pexels ](https://www.pexels.com/zh-cn/photo/317356/?utm_content=attributionCopyText&utm_medium=referral&utm_source=pexels)上的[Lukas ](https://www.pexels.com/zh-cn/@goumbik?utm_content=attributionCopyText&utm_medium=referral&utm_source=pexels)拍摄的照片

#### Screen

> **Screen**是一款由GNU计划开发的用于命令行终端切换的自由软件 . 用户可以通过该软件同时连接多个本地或远程的命令行会话 , 并在其间自由切换 . GNU Screen可以看作是窗口管理器的命令行界面版本 . 它提供了统一的管理多个会话的界面和相应的功能 .

```
$ screen -S <作业名称> 指定screen作业的名称
$ screen -ls或--list 显示目前所有的screen作业
$ screen -r <作业名称> 恢复离线的screen作业
$ screen -d <作业名称> 将指定的screen作业离线
```

又挖了一个坑 , 这里简单的记录几个可能会常用到的命令 , 能做到恢复离线就好 . Screen还有很多有趣的功能 . 总有人说Screen已经没人维护了 , 可以自己去看看 : 

> http://www.gnu.org/software/screen/
> https://git.savannah.gnu.org/cgit/screen.git/log/?h=v.4.7.0

#### Tmux

另一个类似的工具Tmux , 也可以同时管理多个会话 , 它的全称比较高端 , 终端复用器(Terminal multiplexer) . 记忆中隐约用过几次 , 那还是在刚刚更换成MacOS操作系统时 , 在网上搜索iterm2+zsh+tmux之类的文章时用过 . 

网上很多Screen和Tmux对比的文章 , 可供参考 : 

> https://reversed.top/2015-11-08/switching-from-tmux-to-gnu-screen/
> https://wtanaka.com/node/8136
> http://dominik.honnef.co/posts/2010/10/why_you_should_try_tmux_instead_of_screen/

> **相关资料**
https://wiki.archlinux.org/index.php/GNU_Screen_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87)
