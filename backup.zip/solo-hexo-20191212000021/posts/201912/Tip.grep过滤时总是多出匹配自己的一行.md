title: Tip.grep过滤时总是多出匹配自己的一行
date: '2019-12-06 10:08:37'
updated: '2019-12-06 10:08:37'
tags: [tip, grep]
permalink: /articles/2019/12/06/1575598116956.html
---
![closeupphotographyofcoloredpencils743986.jpg](https://img.hacpai.com/file/2019/12/closeupphotographyofcoloredpencils743986-0da3b6cf.jpg)

* [Pexels ](https://www.pexels.com/zh-cn/photo/743986/?utm_content=attributionCopyText&utm_medium=referral&utm_source=pexels)上的[Plush Design Studio ](https://www.pexels.com/zh-cn/@designedbyjess?utm_content=attributionCopyText&utm_medium=referral&utm_source=pexels)拍摄的照片

grep查找时 , 总会显示本身那一行 , 最常见的就是要查找httpd之类的 , 某个进程的运行状态 . 终端查看还好 , 如果要写在shell脚本里 , 还是有必要去掉的 . 

```
#!/bin/sh
read -p "请输入名称:" name
STATUS=`ps -ef | grep "$name" | grep -v "grep"`
if [ ! -z "$STATUS" ];then
    echo "on"
else
    echo "off"
fi
```
