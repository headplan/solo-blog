title: Note.Nginx.架构基础.Nginx的请求处理流程与进程结构
date: '2019-12-04 12:13:13'
updated: '2019-12-04 12:39:08'
tags: [note, nginx, 架构基础]
permalink: /articles/2019/12/04/1575432793763.html
---
![artsbuildcloseupcommerce273230.jpg](https://img.hacpai.com/file/2019/12/artsbuildcloseupcommerce273230-1a66850d.jpg)


### 请求处理流程

Web , Email , TCP 大致有三种流量进入 . Nginx 中有三个大的状态机 :

![nginxqingqiuchuliliucheng.png](https://img.hacpai.com/file/2019/12/nginxqingqiuchuliliucheng-72b058df.png)

* 传输层状态机 : 处理 TCP , UDP 的四层的传输层状态机 .
* HTTP 状态机 : 处理应用层的 HTTP 状态机 .
* Mail 状态机 : 处理邮件的 Mail 状态机 .

**为什么叫状态机呢 ?**

因为 Nginx 中核心的处理引擎是非阻塞的事件驱动处理引擎 , 也就是我们熟知的 epoll . 一旦使用这种异步处理引擎 , 通常都需要状态机把请求正确的识别和处理的 . 基于这样的处理方式 , 在解析出请求 , 需要访问静态资源的时候 , 就会走左下方的**静态资源** . 如果做反向代理的时候 , 对方向代理的内容可以做**磁盘缓存** .

但是在处理静态资源时候会有一个问题 , 当整个内存已经不足以完全的缓存住所有的文件缓存信息时 , 像 sendfile 这样的调用 , 或者 AIO 会退化成阻塞的磁盘调用 . 因为操作系统要缓存 inode , 当内存不足时 , 连 inode 都只能从磁盘读出来时 , 此时的异步 IO 都会退化成阻塞调用 .

可以看下实验过程 :

> [https://www.nginx.com/blog/thread-pools-boost-performance-9x/](#)

所以在上图中会看到一个线程池来处理磁盘阻塞调用 .

对于每一个处理完成的请求 , 会记录 Access 访问日志和 Error 错误日志 . 这里是记录在磁盘中的 , 当然也可以使用 syslog 协议 , 记录到远程的服务器上 .

更多的时候 , Nginx 是作为反向代理或者负载均衡来使用的 , 这个时候可以把请求 , 通过协议把请求传输到后面的服务器 , 例如 HTTP , Mail 及 stream(TCP)代理 . 也可以通过一些应用层的协议代理到相应的应用服务器 , 例如 , FastCGI , uWSGI , SCGI , Memcached 代理 .

### 进程结构

Nginx 有两种进程结构 , 单进程结构和多进程结构 .

**单进程结构**不适用于生产环境 , 只适用于开发和调试 . 生产环境中 , 必须保证 nginx 足够健壮 , 并且 nginx 可以利用多核的特性 , 单进程结构无法满足 . 所以 nginx 的默认配置中都是打开为多进程结构的 nginx .

配置文件 :

```
worker_processes auto;
# 或者
worker_processes 8; # CPU核数的2倍
```

#### Nginx 的多进程模型

![nginxduojinchengmoxing.png](https://img.hacpai.com/file/2019/12/nginxduojinchengmoxing-32bd409b.png)

**为什么 Nginx 采用多进程结构 , 而不是多线程结构呢 ?**

答案是 , 为了保证 Nginx 的高可用性和高可靠性 .

如果使用多线程结构的情况下 , 线程之间是共享同一个地址空间的 , 所以当某一个第三方模块引发了一个地址空间导致的段错误时 , 也就是在地址越界出现时 , 会导致整个 Nginx 的进程全部挂掉 . 当我们采用多进程的 Nginx 进程模型时 , 往往就不会出现类似的情况 .

Nginx 在做进程设计时 , 同样遵循了实现高可用和高可靠的目的 . 在 master 进程中 , 第三方模块通常不会在其中加入自定义的功能代码的 , 虽然这是允许的 , 但通常没有第三方模块会这样做 . master 进程的目的 , 就是用来管理 worker 进程的 . 也就是说 , 所有的 worker 进程是处理真正的请求的 , 而 master 进程负责监控每个 worker 进程是不是在正常的工作 , 需不需要做重新载入配置文件 , 需不需要做热部署 . 说道缓存的时候 , 缓存是需要在多个 worker 进程间共享的 , 而且缓存不光要被 worker 进程使用 , 还要被 Cache Manager 和 Cache Loader 进程使用 , Cache Manager 和 Cache Loader 也是为反向代理时 , 后端发来的动态请求做缓存所使用的 . Cache Loader 只是用来做缓存的载入 , Cache Manager 用来做缓存的管理 . 实际上 , 每个请求处理时 , 使用到缓存 , 还是通过 worker 进程来进行的 . 这些进程间的通讯是使用共享内存来解决的 .

**为什么有多个 worker 进程 ?**

Nginx 采用了四列驱动的模型以后 , 希望每一个 worker 进程从头到尾都占有一颗 CPU , 所以往往不只要把 worker 进程的数量配置成和 CPU 核数一致 , 还要把每个 worker 进程与某一颗 CPU 核绑定在一起 , 这样可以更好的使用没颗 CPU 核上面的 CPU 缓存来减少缓存失效的命中率 .

2 核 CPU , 开启 2 个进程 :

```
worker_processes     2;
worker_cpu_affinity 01 10;
```

2 核 CPU , 开启 4 个进程 :

```
worker_processes     4;
worker_cpu_affinity 01 10 01 10;
```

4 个 CPU , 开启 4 个进程 :

```
worker_processes     4;
worker_cpu_affinity 0001 0010 0100 1000;
```

8 核 CPU , 开启 8 个进程 :

```
worker_processes     8;
worker_cpu_affinity 00000001 00000010 00000100 00001000 00010000 00100000 01000000 10000000;
```

#### Nginx 的进程结构实例演示

前面提到 , nginx 使用了多进程模型 , 也知道了 nginx 的父子进程之间是通过信号管理的 .

**那这些父子进程以及信号之间是如何工作的呢 ?**

![jinchengid.png](https://img.hacpai.com/file/2019/12/jinchengid-ca2eb8c4.png)

通过 ps 命令 , 可以看到 nginx:master 进程是用 root 用户起的 , 进程的 id 是 3544 , 两个 worker 进程都是通过 3544 起来的 . 两个 worker 进程的 id 是 18348 , 18349 .

现在执行 :

```
nginx -s reload
```

优雅的退出 worker 进程 , 再使用新的配置项启动新的子进程 . 这里虽然没有改变配置 , 但是可以看到 , 老的子进程会退出 , 然后生成新的子进程 .

![xindezijincheng.png](https://img.hacpai.com/file/2019/12/xindezijincheng-158a0b41.png)

可以看到之前的子进程都不在了 , 由 3544master 进程新启动了两个子进程 30552 , 30553 . 之前说过 , reload 和 HUP 信号的作用是相同的 . 现在向 nginx 的 master 进程 3544 发送 HUP 信号 :

```
kill -SIGHUP 3544
```

![fasonghupxinhao.png](https://img.hacpai.com/file/2019/12/fasonghupxinhao-d1506352.png)

之前我们还提过 , 像 quit , stop 他们都有相应的信号 , 如果向一个 worker 进程 , 比如 31249 , 发送一个退出信号 , 那么这个 worker 进程就会退出 , 而且进程在退出时 , 会自动的向其父进程 3544 , 也就是 master 进程发送一个 , SIGCHILD 信号 , 这个信号收到以后 , master 进程就知道他的子进程退出了 , 他会新启一个 worker 进程 , 维持当前两个 worker 进程的进程结构 :

```
kill -SIGTERM 31249
```

![sigtermxinhao.png](https://img.hacpai.com/file/2019/12/sigtermxinhao-10d168e9.png)

> **相关参考**
http://nginx.org/en/
http://nginx.taohui.org.cn/
http://tengine.taobao.org/book/index.html

