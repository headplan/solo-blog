title: 'Debug.Docker中使用Systemd报错.Failed to get D-Bus connection: Operation not permitted'
date: '2019-12-03 10:20:51'
updated: '2019-12-03 10:32:27'
tags: [debug, docker]
permalink: /articles/2019/12/03/1575339650869.html
---
![additionblackandwhiteblackandwhitechalk374918.jpg](https://img.hacpai.com/file/2019/12/additionblackandwhiteblackandwhitechalk374918-f27b5008.jpg)


看阮一峰写的Systemd相关的文章 , 打算试一试其中的命令 , 就打开Mac中的Docker , 随便找了一个之前在跑着的nginx的容器 . 直接通过Kitematic进入 , 输入 : 

```
sh-4.2# systemctl reboot
Failed to get D-Bus connection: Operation not permitted
```
还以为是容器镜像的问题 , 就又找了个直接就是CentOS的镜像 . 结果 : 

```
sh-4.4# systemctl reboot
System has not been booted with systemd as init system (PID 1). Can't operate.
Failed to connect to bus: Host is down
```
**解决方案**

Docker中无法使用systemd管理服务的原因是1号进程不是init , 而是其他例如 `/bin/bash` , 所以导致缺少相关文件无法运行 . 

创建容器时配置对应的参数 : 

```
docker run -tid --name bitch --privileged=true ubuntu:18.04 /sbin/init
docker exec -it bitch /bin/bash
```
