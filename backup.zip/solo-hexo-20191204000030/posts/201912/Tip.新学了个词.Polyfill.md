title: Tip.新学了个词.Polyfill
date: '2019-12-03 12:44:03'
updated: '2019-12-03 12:44:03'
tags: [tip, 前端, js]
permalink: /articles/2019/12/03/1575348243312.html
---
![photoofscarletmacawperchingonbrownwoodenboard1478419.jpg](https://img.hacpai.com/file/2019/12/photoofscarletmacawperchingonbrownwoodenboard1478419-e28d523c.jpg)
* *[Pexels ](https://www.pexels.com/zh-cn/photo/1478419/?utm_content=attributionCopyText&utm_medium=referral&utm_source=pexels)上的[James Frid ](https://www.pexels.com/zh-cn/@james-frid-81279?utm_content=attributionCopyText&utm_medium=referral&utm_source=pexels)拍摄的照片*

最近在看前端的资料 , 然后就是各种的身体和心里的不适 . 为了缓解一下 , 这里记录一些有趣的新发现 . 今天新学了一个词 : Polyfill . (我只记得Poly是只鹦鹉来着...)

MDN上的解释是 : 

> Polyfill 是一块代码（通常是 Web 上的 JavaScript），用来为旧浏览器提供它没有原生支持的较新的功能。
> 
> 比如说 polyfill 可以让 IE7 使用 Silverlight 插件来模拟 HTML Canvas 元素的功能，或模拟 CSS 实现 rem 单位的支持，或 `text-shadow`，或其他任何你想要的功能。

顺着大前端复杂的脉络 , 又发现了几个有趣的东西 , 随后跟进 : 

* [Babel](https://babeljs.io/) - 下一代 JavaScript 语法的编译器 . 
* [Promise对象](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise) - 在ES6中被统一规范 , 由浏览器直接支持 . 
* https://caniuse.com/ - can i use 随便搜索一个词 . 例如 , promise就会出现各个浏览器兼容情况 . 
* [Axios](https://github.com/axios/axios) - 是一个基于promise的HTTP库 , 可以用在浏览器和node.js中 . 
* [bluebird](http://bluebirdjs.com/docs/getting-started.html) - 让所有浏览器都支持ES6 Promise对象 . 
* [Fetch API](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API) - 是一种HTTP数据请求的方式 , 是XMLHttpRequest的一种替代方案 . fetch不是ajax的进一步封装 , 而是原生js . Fetch函数就是原生js , 没有使用XMLHttpRequest对象 . 

**相关链接**
https://developer.mozilla.org/zh-CN/docs/Glossary/Polyfill

